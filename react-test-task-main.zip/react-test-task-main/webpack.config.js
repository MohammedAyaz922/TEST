var webpack = require("webpack");
var { resolve } = require("path");
const HtmlWebpackPlugin= require('html-webpack-plugin');

module.exports = {
    entry:{
      index:resolve(__dirname,"src","index.js")
    },
  module: {
    rules: [
      {
         test:/\.(js|jsx)$/,
         exclude:/node_modules/,
        use:['babel-loader']
      },
      {
        test: /\.scss$/,
        use: ["style-loader", "css-loader", "sass-loader"]
      }
    ]
  },
  resolve: {
    extensions: ["*", ".js", ".jsx"]
  },
  output: {
    path: resolve(__dirname, "dist"),
    publicPath: "/",
    filename: "main.js"
  },
  devServer: {
    contentBase: "./dist",
    hot: true
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: resolve(__dirname,'public','index.html')
    })
  ]
};
