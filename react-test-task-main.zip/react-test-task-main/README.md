# react-test-task

## Project is configured with webpack

## To Run in local, execute npm run dev command
##  In Browser, http://localhost:8080 link to load the application
