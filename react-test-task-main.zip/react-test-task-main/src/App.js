import React from "react";
import "./styles.scss";
import AddDynamicItem from "./components/addDynamicItem";
import MultiColumnList from "./components/multiColumnList";
const productCols = [
  {
    label: "Product Category",
    colType: "productCategory"
  },
  {
    label: "Product Name",
    colType: "productName"
  }
];
const intialState = {
  productCategory: [],
  productName: []
};

function reducer(state, action) {
  switch (action.type) {
    case "ADD_ITEM":
      const { key, value } = action.payload;
      const newElemt = [...state[key]];
      newElemt.push(value);
      return {
        ...state,
        [key]: newElemt
      };
    case "REMOVE_ITEM":
      const { key: k, value: v } = action.payload;
      const filtData = state[k].filter((item) => item !== v);
      return {
        ...state,
        [k]: filtData
      };
    default:
      return state;
  }
}
export default function App() {
  const [state, dispatch] = React.useReducer(reducer, intialState);
  const addItemToColumn = (key, value) => {
    dispatch({
      type: "ADD_ITEM",
      payload: { key, value }
    });
  };
  const removeItemFromCol = (key, value) => {
    dispatch({
      type: "REMOVE_ITEM",
      payload: { key, value }
    });
  };
  console.log(state);
  return (
    <div className="App">
      <div className="div-padding ">
        <label className="header__label">{"Add Items To Columns"}</label>
        <hr />
        <AddDynamicItem cols={productCols} addItem={addItemToColumn} />
      </div>
      <div className="div-padding" style={{ marginTop: "20px" }}>
        <label className="header__label">{"Item List In Columns"}</label>
        <hr />
        <MultiColumnList
          cols={productCols}
          removeItem={removeItemFromCol}
          data={state}
        />
      </div>
    </div>
  );
}
