import React, { useEffect, useState } from "react";

const UseColumnSearch = (searchVal, OrgData) => {
  const [filteredData, setFilteredData] = useState({});

  useEffect(() => {
    if (searchVal) {
      let tempData = {};
      Object.keys(OrgData).forEach((key) => {
        tempData[key] = OrgData[key].filter((item) => {
          if (item.toLowerCase().indexOf(searchVal.toLowerCase()) >= 0)
            return true;
          else return false;
        });
      });
      setFilteredData(tempData);
    } else {
      setFilteredData(OrgData);
    }
  }, [searchVal, OrgData]);

  return filteredData;
};

export default UseColumnSearch;
