import React, { useState } from "react";

const AddDynamicItem = ({ cols, addItem }) => {
  const [itemName, setItemName] = useState("");
  const [column, setColumn] = useState(cols[0].colType);
  const handleChange = (e) => {
    setItemName(e.target.value);
  };
  const getOptions = () => {
    return cols.map((item) => (
      <option value={item.colType}>{item.label}</option>
    ));
  };
  const onAddItemClick = () => {
    addItem(column, itemName);
    setItemName("");
  };
  const onSelected = (e) => {
    setColumn(e.target.value);
  };
  return (
    <div className="add-section-container div-padding">
      <div>
        <input
          type="text"
          onChange={handleChange}
          value={itemName}
          placeholder="Enter Item here "
        />
      </div>
      <div>
        <select value={column} onChange={onSelected}>
          {getOptions()}
        </select>
      </div>
      <div>
        <button onClick={onAddItemClick} className="btn btn-small">
          Add Item
        </button>
      </div>
    </div>
  );
};
export default AddDynamicItem;
