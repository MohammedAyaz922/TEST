import React, { useEffect, useState } from "react";
import RenderListItems from "./RenderListItems";
import useDebounce from "../customHook/useDebounce";
import useColumnSearch from "../customHook/useColumnSearch";

const MultiColumnList = ({ data, cols, removeItem }) => {
  const [searchVal, setSearchVal] = useState("");
  const debouncedVal = useDebounce(searchVal, 1000);
  const filteredData = useColumnSearch(debouncedVal, data);
  const handleChange = (e) => {
    setSearchVal(e.target.value);
  };

  return (
    <div className="div-padding">
      <div>
        <input
          type="text"
          className="searchbar"
          placeholder="Search Item here"
          onChange={handleChange}
        />
      </div>
      <div className="list-container margintop-20">
        {Object.keys(filteredData).map((key) => {
          let tmp = cols.find((it) => it.colType === key);
          return (
            <RenderListItems
              list={filteredData[key]}
              colObj={tmp}
              removeItem={removeItem}
            />
          );
        })}
      </div>
    </div>
  );
};

export default MultiColumnList;
