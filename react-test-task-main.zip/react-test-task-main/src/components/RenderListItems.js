import React from "react";

const renderListItems = ({ colObj, list, removeItem }) => {
  const onCloseItem = (e, value) => {
    removeItem(colObj.colType, value);
  };
  console.log(list);
  return (
    <div className="card-main marginright-20">
      <div className="card-divider">
        <h5 className="card-header">{colObj.label}</h5>
      </div>
      <ul>
        {list.map((item) => (
          <li>
            <span>{item}</span>
            <button
              className="icon btn__icon-right"
              onClick={(e) => onCloseItem(e, item)}
            >
              <i className="fa fa-close"></i>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default renderListItems;
